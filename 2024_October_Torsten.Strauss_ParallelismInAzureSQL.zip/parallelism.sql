/*******************************************************************************

	Date:					October 2024
	Session:				Parallelism in Azure SQL
	SQL Server Version:		2017 +

	Author:					Torsten Strauss
							https://inside-sqlserver.com 

	This script is intended only as a supplement to demos and lectures
	given by Torsten Strauss.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.

*******************************************************************************/

/*******************************************************************************

	parallelism - preparation

*******************************************************************************/

-- Do not execute!
SET PARSEONLY ON;
GO

EXEC sys.sp_configure 'show advanced options', 1;
RECONFIGURE;
GO

USE AdventureWorks2017;
GO

-- Create a table
DROP TABLE IF EXISTS test;
GO

CREATE TABLE test ( col1 int NOT NULL);
GO

WITH cte
AS
	(
		SELECT numbers.col1
		FROM ( VALUES ( 0 )
			   ,	  ( 1 )
			   ,	  ( 2 )
			   ,	  ( 3 )
			   ,	  ( 4 )
			   ,	  ( 5 )
			   ,	  ( 6 )
			   ,	  ( 7 )
			   ,	  ( 8 )
			   ,	  ( 9 )
			 ) AS numbers ( col1 )
	)
INSERT dbo.test
	(
		col1
	)
SELECT (c1.col1 * 100000 + c2.col1 * 10000 + c3.col1 * 1000 + c4.col1 * 100
		+ c5.col1 * 10 + c6.col1 * 1
	   ) % 2
FROM
	cte AS c1
CROSS JOIN cte AS c2
CROSS JOIN cte AS c3
CROSS JOIN cte AS c4
CROSS JOIN cte AS c5
CROSS JOIN cte AS c6;
GO



-- Create a table
DROP TABLE IF EXISTS big_table1;
GO

CREATE TABLE big_table1
(
	id int IDENTITY NOT NULL
  , col1 int NOT NULL
  , col2 int NOT NULL
  , filler char(200) NULL
);
GO

WITH cte
AS
	(
		SELECT numbers.col1
		FROM ( VALUES ( 0 )
			   ,	  ( 1 )
			   ,	  ( 2 )
			   ,	  ( 3 )
			   ,	  ( 4 )
			   ,	  ( 5 )
			   ,	  ( 6 )
			   ,	  ( 7 )
			   ,	  ( 8 )
			   ,	  ( 9 )
			 ) AS numbers ( col1 )
	)
INSERT big_table1
	(
		col1, col2
	)
SELECT (c1.col1 * 100000 + c2.col1 * 10000 + c3.col1 * 1000 + c4.col1 * 100
		+ c5.col1 * 10 + c6.col1 * 1
	   )
  , (c1.col1 * 100000 + c2.col1 * 10000 + c3.col1 * 1000 + c4.col1 * 100
	 + c5.col1 * 10 + c6.col1 * 1
	) % 2
FROM
	cte AS c1
CROSS JOIN cte AS c2
CROSS JOIN cte AS c3
CROSS JOIN cte AS c4
CROSS JOIN cte AS c5
CROSS JOIN cte AS c6;
GO

ALTER TABLE big_table1 ADD CONSTRAINT PKCL_big_table1_id PRIMARY KEY (id);
GO



-- Create a table
DROP TABLE IF EXISTS big_table2;
GO

CREATE TABLE big_table2
(
	id int IDENTITY NOT NULL
  , col1 int NOT NULL
  , col2 int NOT NULL
  , filler char(200) NULL
);
GO

WITH cte
AS
	(
		SELECT numbers.col1
		FROM ( VALUES ( 0 )
			   ,	  ( 1 )
			   ,	  ( 2 )
			   ,	  ( 3 )
			   ,	  ( 4 )
			   ,	  ( 5 )
			   ,	  ( 6 )
			   ,	  ( 7 )
			   ,	  ( 8 )
			   ,	  ( 9 )
			 ) AS numbers ( col1 )
	)
INSERT big_table2
	(
		col1, col2
	)
SELECT (c1.col1 * 100000 + c2.col1 * 10000 + c3.col1 * 1000 + c4.col1 * 100
		+ c5.col1 * 10 + c6.col1 * 1
	   )
  , (c1.col1 * 100000 + c2.col1 * 10000 + c3.col1 * 1000 + c4.col1 * 100
	 + c5.col1 * 10 + c6.col1 * 1
	) % 2
FROM
	cte AS c1
CROSS JOIN cte AS c2
CROSS JOIN cte AS c3
CROSS JOIN cte AS c4
CROSS JOIN cte AS c5
CROSS JOIN cte AS c6;
GO

ALTER TABLE big_table2 ADD CONSTRAINT PKCL_big_table2_id PRIMARY KEY (id);
GO



DROP TABLE IF EXISTS GuidHighFragmentation;
GO

CREATE TABLE GuidHighFragmentation
(
	UniqueID uniqueidentifier
		DEFAULT NEWID () PRIMARY KEY
  , FirstName nvarchar(50) NOT NULL
  , LastName nvarchar(50) NOT NULL
);
GO

CREATE NONCLUSTERED INDEX IX_GuidHighFragmentation_LastName
ON GuidHighFragmentation (LastName);
GO

INSERT INTO GuidHighFragmentation
	(
		FirstName
	  , LastName
	)
SELECT TOP 100000
	a.name, b.name
FROM
	master.dbo.spt_values AS a
CROSS JOIN master.dbo.spt_values AS b
WHERE
	a.name IS NOT NULL
	AND b.name IS NOT NULL
ORDER BY
	NEWID ();
GO 30


DROP TABLE IF EXISTS GuidLowFragmentation;
GO

CREATE TABLE GuidLowFragmentation
(
	UniqueID uniqueidentifier
		DEFAULT NEWSEQUENTIALID () PRIMARY KEY
  , FirstName nvarchar(50) NOT NULL
  , LastName nvarchar(50) NOT NULL
);
GO

CREATE NONCLUSTERED INDEX IX_GuidLowFragmentation_LastName
ON GuidLowFragmentation (LastName);
GO

INSERT INTO GuidLowFragmentation
	(
		UniqueID
	  , FirstName
	  , LastName
	)
SELECT
	UniqueID, FirstName, LastName
FROM
	GuidHighFragmentation;
GO

ALTER INDEX ALL ON GuidLowFragmentation REBUILD;
GO


DROP TABLE IF EXISTS parallel_function;
GO

-- Create a table with 3.000.000 rows
SELECT
	UniqueID, FirstName, LastName
INTO parallel_function
FROM
	GuidHighFragmentation;
GO

-- Create a deterministic scalar function 
DROP FUNCTION IF EXISTS dbo.upperCase;
GO

CREATE FUNCTION dbo.upperCase
(
	@var AS nvarchar(50)
)
RETURNS nvarchar(50)
WITH SCHEMABINDING
AS
	BEGIN
		DECLARE @upper_value nvarchar(50);
		SET @upper_value = UPPER (@var);

		RETURN @upper_value;
	END;
GO

-- Add a new calculated persisted column which uses the scalar function
ALTER TABLE parallel_function
ADD UpperFirstName AS dbo.upperCase (FirstName) PERSISTED NOT NULL;
GO

-- Rebuild the table
ALTER TABLE parallel_function REBUILD; 
GO	

-- Create a non-clustered index on the calculated column
CREATE INDEX NCL_parallel_function_UpperFirstName
ON dbo.parallel_function (UpperFirstName);
GO

-- Update the statistics
UPDATE STATISTICS parallel_function NCL_parallel_function_UpperFirstName
WITH
	ROWCOUNT = 10000000000, PAGECOUNT = 10000000;
GO



/*******************************************************************************

	parallelism - table used

*******************************************************************************/

USE AdventureWorks2017;
GO

-- Get some sample records
SELECT TOP 10 * FROM dbo.test;
GO

-- Get some sample records
SELECT TOP 10 * FROM dbo.big_table1;
GO

-- Get some sample records
-- Copy of big_table1
SELECT TOP 10 * FROM dbo.big_table2;
GO

-- Get some sample records
SELECT TOP 10 * FROM dbo.GuidLowFragmentation;
GO

-- Get some sample records
SELECT TOP 10 * FROM dbo.GuidHighFragmentation;
GO

SELECT TOP 10 * FROM dbo.parallel_function;
GO

-- test: 1000000 rows
-- big_table1: 1.000.000 rows
-- big_table2: 1.000.000 rows
-- GuidHighFragmentation: 3.000.000 rows
-- GuidLowFragmentation: 3.000.000 rows
-- parallel_function: 3.000.000 rows
SELECT
	s.name + '.' + t.name AS table_name
  , (
		SELECT SUM (p2.rows)
		FROM
			sys.indexes AS i2
		INNER JOIN
			sys.partitions AS p2
		ON
			i2.object_id = p2.object_id
			AND i2.index_id = p2.index_id
		WHERE
			i2.object_id = t.object_id
			AND i2.object_id > 255
			AND
				(
					i2.index_id = 0
					OR i2.index_id = 1
				)
	) AS total_rows
  , SUM (	CASE
				WHEN (i.index_id = 0)
					 OR (i.index_id = 1)
					 THEN a.total_pages * 8
				ELSE 0
			END
		) AS data_size_kb
  , SUM (CASE WHEN (i.index_id = 0) OR (i.index_id = 1) THEN a.used_pages * 8 ELSE
				   0 END
		) AS data_used_kb
  , SUM (	CASE
				WHEN (i.index_id = 0)
					 OR (i.index_id = 1)
					 THEN 0
				ELSE a.total_pages * 8
			END
		) AS index_size_kb
  , SUM (CASE WHEN (i.index_id = 0) OR (i.index_id = 1) THEN 0 ELSE
				   a.used_pages * 8 END
		) AS index_used_kb
  , SUM (a.total_pages) * 8 AS total_size_kb
  , SUM (a.used_pages) * 8 AS total_used_kb
  , SUM (a.used_pages) * 100
	/ CASE WHEN SUM (a.total_pages) = 0 THEN 1 ELSE SUM (a.total_pages) END AS percent_full
FROM
	sys.tables AS t
INNER JOIN
	sys.schemas AS s
ON
	s.schema_id = t.schema_id
INNER JOIN
	sys.indexes AS i
ON
	t.object_id = i.object_id
INNER JOIN
	sys.partitions AS p
ON
	i.object_id = p.object_id
	AND i.index_id = p.index_id
INNER JOIN
	sys.allocation_units AS a
ON
	p.partition_id = a.container_id
WHERE
	t.is_ms_shipped = 0
	AND t.object_id IN (
						   OBJECT_ID ('dbo.test')
						 , OBJECT_ID ('dbo.big_table1')
						 , OBJECT_ID ('dbo.big_table2')
						 , OBJECT_ID ('dbo.GuidHighFragmentation')
						 , OBJECT_ID ('dbo.GuidLowFragmentation')
						 , OBJECT_ID ('dbo.parallel_function')
					   )
GROUP BY
	t.object_id, t.name, s.name;
GO



/*******************************************************************************

	parallelism

*******************************************************************************/

/*

	SQL Server can execute queries using multiple CPUs or cores simultaneously.
	
	Parallelism increases the overhead associated with executing a query which 
	influence the overall execution time of the query. 

	Parallelism assigns more threads to a query execution and can therefore 
	lead to thread pool starvation and system performance degradation.

	Parallelism is only useful on servers running a relatively small number of 
	concurrent queries.
	
	SQL Server parallelizes queries by horizontally partitioning the input data 
	into approximately equal-sized sets, assigning one set to each CPU or core, 
	and then performing the same operation (such as aggregate, join, sort, 
	etc.) on each set.

	There is no guarantee that the best parallel plan found will have a lower 
	cost than the best serial plan, so the serial plan may still end up being 
	the better plan.

	For the optimizer even to consider a parallel plan, the following criteria 
	must be met:

	*	SQL Server must be running on a multiprocessor, multicore or 
		hyperthreaded machine.
		
	*	The processor affinity configuration must allow SQL Server to use at 
		least two processors.
		
	*	The max degree of parallelism advanced configuration option must be 
		set to zero (the default) or to more than one.
		
	*	The MAX_DOP configuration for Resource Governor must also allow the 
		use of parallel plans.
		
	*	The estimated cost to run a serial plan for a query is higher than the 
		value set in cost threshold for parallelism.

*/



/*******************************************************************************

	parallelism - system requirements

*******************************************************************************/

/*******************************************************************************

	parallelism - system requirements
	multiprocessor, multicore or hyperthreaded 

*******************************************************************************/

/*
	
	SQL Server must be running on a multiprocessor, multicore or hyperthreaded 
	machine.

*/

-- cpu_count : number of logical CPUs on the system
-- hyperthread_ratio : number of logical cores
-- physical_cpu_count : number of physical cores
SELECT
	cpu_count
  , hyperthread_ratio
  , cpu_count / hyperthread_ratio AS physical_cpu_count
FROM
	sys.dm_os_sys_info;
GO



/*******************************************************************************

	parallelism - system requirements
	maximum degree of parallelism

*******************************************************************************/

/*

	The max degree of parallelism advanced configuration option must be set to 
	zero (the default) or to more than one to run a query in parallel.

	The MAX_DOP configuration for Resource Governor must also allow the use of 
	parallel plans.

*/



/*******************************************************************************

	parallelism - system requirements
	cost threshold for parallelism

*******************************************************************************/

/*	
	
	The estimated cost to run a serial plan for a query must higher than the 
	value set in cost threshold for parallelism to execute a query in parallel.

*/

-- Set cost threshold for parallelism to 5 (default)
EXEC sys.sp_configure 'cost threshold for parallelism', 5;
RECONFIGURE;
GO

-- cost threshold for parallelism : 5 (default)
SELECT
	name, value_in_use
FROM
	sys.configurations
WHERE
	name = N'cost threshold for parallelism';
GO

USE AdventureWorks2017;
GO

-- Force to run the query on one core only 
-- NonParallelPlanReason : MaxDOPSetToOne
-- Degree of Parallelism : 0
-- Costs : 29,125
SELECT
	col1, COUNT (col1)
FROM
	big_table1
GROUP BY
	col1
OPTION (RECOMPILE, MAXDOP 1);
GO

-- Query is running in parallel
-- Degree of Parallelism : 8
-- Costs : 29,125 > cost threshold for parallelism 5
-- Costs : 21,9063 | 29,125
SELECT
	col1, COUNT (col1)
FROM
	big_table1
GROUP BY
	col1
OPTION (RECOMPILE)
GO


-- Enable the query store and purge the data
ALTER DATABASE CURRENT SET QUERY_STORE = ON;
ALTER DATABASE CURRENT SET QUERY_STORE CLEAR;
GO

-- A parallel plan is not considered due to the MAXDOP limitation.
-- TraceFlag 8675 shows the query optimization phases for a specific optimization.
-- Search phase 1 and 2 are executed one time only each.
-- end search(1),  cost: 70712.3 tasks: 2539 time: 0 net: 0 total: 0 net: 0.01
-- end search(2),  cost: 70712.3 tasks: 2777 time: 0 net: 0 total: 0 net: 0.012
SELECT COUNT(*)
FROM
	Production.Product AS pr
INNER JOIN
	Production.ProductSubcategory AS su
ON
	pr.ProductSubcategoryID = su.ProductSubcategoryID
INNER JOIN
	Sales.SalesOrderDetail AS de
ON
	de.ProductID = pr.ProductID
LEFT JOIN
	Production.ProductSubcategory
ON
	pr.ProductSubcategoryID = pr.ProductSubcategoryID
INNER JOIN
	Sales.SpecialOffer AS soff
ON
	de.SpecialOfferID = soff.SpecialOfferID
LEFT JOIN
	Sales.SalesOrderHeader AS he
ON
	he.SalesOrderID = de.SalesOrderID
OPTION (MAXDOP 1, QUERYTRACEON 8675, QUERYTRACEON 3604);
GO

-- A parallel plan is considered.
-- Search phase 1 is executed two times.
-- First optimization in search phase 1 considers the serial plan the second 
-- considers the parallel plan.
-- end search(1),  cost: 70712.3 tasks: 2539 time: 0 net: 0 total: 0 net: 0.012
-- end search(1),  cost: 67414.8 tasks: 4744 time: 0 net: 0 total: 0 net: 0.022
-- end search(2),  cost: 67414.8 tasks: 5137 time: 0 net: 0 total: 0 net: 0.024
SELECT COUNT(*)
FROM
	Production.Product AS pr
INNER JOIN
	Production.ProductSubcategory AS su
ON
	pr.ProductSubcategoryID = su.ProductSubcategoryID
INNER JOIN
	Sales.SalesOrderDetail AS de
ON
	de.ProductID = pr.ProductID
LEFT JOIN
	Production.ProductSubcategory
ON
	pr.ProductSubcategoryID = pr.ProductSubcategoryID
INNER JOIN
	Sales.SpecialOffer AS soff
ON
	de.SpecialOfferID = soff.SpecialOfferID
LEFT JOIN
	Sales.SalesOrderHeader AS he
ON
	he.SalesOrderID = de.SalesOrderID
OPTION (QUERYTRACEON 8675, QUERYTRACEON 3604);
GO

-- Get the compile time for the queries in cache
DROP TABLE IF EXISTS #query_store_query;
DROP TABLE IF EXISTS #query_store_plan;

SELECT
	qsq.query_id
  , qsq.query_text_id
  , qsq.query_hash
  , qsq.initial_compile_start_time
  , qsq.last_compile_start_time
  , qsq.last_execution_time
  , qsq.count_compiles
  , qsq.last_compile_duration / 1000000. AS last_compile_duration
  , qsq.avg_compile_duration / 1000000. AS avg_compile_duration
  , qsq.avg_bind_duration / 1000000. AS avg_bind_duration
  , qsq.avg_bind_cpu_time / 1000000. AS avg_bind_cpu_time
  , qsq.avg_optimize_duration / 1000000. AS avg_optimize_duration
  , qsq.avg_optimize_cpu_time / 1000000. AS avg_optimize_cpu_time
  , qsq.avg_compile_memory_kb / 1024. AS avg_compile_memory_mb
  , qsq.max_compile_memory_kb / 1024. AS max_compile_memory_mb
INTO #query_store_query
FROM
	sys.query_store_query AS qsq
WHERE
	qsq.is_internal_query = 0
ORDER BY
	avg_compile_duration DESC
OPTION (RECOMPILE);
SELECT
	qsp.plan_id
  , qsp.query_id
  , qsp.engine_version
  , qsp.count_compiles
  , qsp.initial_compile_start_time
  , qsp.last_compile_start_time
  , qsp.last_execution_time
  , qsp.avg_compile_duration / 1000000. AS avg_compile_duration
  , qsp.last_compile_duration / 1000000. AS last_compile_duration
  , TRY_CONVERT (xml, qsp.query_plan) AS query_plan
INTO #query_store_plan
FROM
	sys.query_store_plan AS qsp
ORDER BY
	qsp.avg_compile_duration DESC
OPTION (RECOMPILE);

SELECT
	last_dop
  , qsrs.avg_cpu_time
  , qsrs.avg_duration
  , qsq.avg_compile_duration
  , qsq.avg_bind_duration
  , qsq.avg_bind_cpu_time
  , qsq.avg_optimize_duration
  , qsq.avg_optimize_cpu_time
  , qsq.avg_compile_memory_mb
  , qsp.avg_compile_duration
  , qsq.count_compiles
  , qsrs.count_executions
  , qsp.engine_version
  , qsp.query_id
  , qsp.plan_id
  , qsq.query_hash
  , TRY_CONVERT (xml, qsp.query_plan) AS query_plan
  , qsqt.query_sql_text
  , qsrs.first_execution_time
  , qsrs.last_execution_time
  , qsq.initial_compile_start_time
  , qsq.last_compile_start_time
  , qsq.last_execution_time
FROM
	#query_store_query AS qsq
JOIN
	#query_store_plan AS qsp
ON
	qsq.query_id = qsp.query_id
JOIN
	sys.query_store_query_text AS qsqt
ON
	qsqt.query_text_id = qsq.query_text_id
JOIN
	(
		SELECT
			qsrs.plan_id
		  , qsrs.first_execution_time
		  , qsrs.last_execution_time
		  , qsrs.count_executions
		  , qsrs.last_dop
		  , qsrs.avg_duration / 1000000. AS avg_duration
		  , qsrs.avg_cpu_time / 1000000. AS avg_cpu_time
		FROM
			sys.query_store_runtime_stats AS qsrs
	) AS qsrs
ON
	qsrs.plan_id = qsp.plan_id
WHERE
	qsq.query_hash IN (
						  0x7C1A7495BCBA2204, 0x9A6A4E26C0796643
					  )
ORDER BY
	qsq.avg_compile_duration DESC
OPTION (RECOMPILE);

DROP TABLE IF EXISTS #query_store_query;
DROP TABLE IF EXISTS #query_store_plan;
GO

-- Housekeeping
EXEC sys.sp_configure 'cost threshold for parallelism', 5;
RECONFIGURE;
GO



/*******************************************************************************

	parallelism - QueryTraceOn 8649 and ENABLE_PARALLEL_PLAN_PREFERENCE

*******************************************************************************/

/*
	
	QueryTraceOn 8649 and the query hint ENABLE_PARALLEL_PLAN_PREFERENCE will 
	force SQL Server to use a parallel plan if possible.

*/

USE AdventureWorks2017;
GO

-- Set cost threshold for parallelism to 50
EXEC sys.sp_configure 'cost threshold for parallelism', 50;
RECONFIGURE;
GO

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

-- Degree of Parallelism : 1
-- CPU time = 344 ms,  elapsed time = 431 ms.
-- Costs : 29,125
SELECT
	col1, COUNT (col1)
FROM
	big_table1
GROUP BY
	col1
OPTION (RECOMPILE)
GO

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

-- Parallel plan forced by QueryTraceOn 8649
-- Almost no performance gain but keeping more CPUs busy.
-- Degree of Parallelism : 8
-- CPU time = 1185 (344) ms,  elapsed time = 374 (431) ms
-- Costs : 21,9603 | 29,125
SELECT
	col1, COUNT (col1)
FROM
	big_table1
GROUP BY
	col1
OPTION (QUERYTRACEON 8649);
GO

-- Alternative
-- Parallel plan forced by ENABLE_PARALLEL_PLAN_PREFERENCE 8649
SELECT
	col1, COUNT (col1)
FROM
	big_table1
GROUP BY
	col1
OPTION (USE HINT ('ENABLE_PARALLEL_PLAN_PREFERENCE'));
GO

-- Housekeeping
EXEC sys.sp_configure 'cost threshold for parallelism', 50;
RECONFIGURE;
GO



/*******************************************************************************

	parallelism - processor affinity

*******************************************************************************/

/*

	To carry out multitasking, Microsoft Windows sometimes move threads among 
	different processors. Although efficient from an operating system point of 
	view, this activity can reduce SQL Server performance under heavy system 
	loads, as each processor cache is repeatedly reloaded with data. 
	Assigning processors to specific threads can improve performance under these 
	conditions by eliminating processor reloads and reducing thread migration 
	across processors, which reduces context switching. Such an association 
	between a thread and a processor is called processor affinity.

	By segregating SQL Server threads from running on particular processors, 
	Microsoft Windows can better evaluate the system's handling of processes 
	specific to Windows. 
	For example, on an 8-CPU server running two instances of SQL Server 
	(instance A and B), the system administrator could use the affinity mask 
	option to assign the first set of 4 CPUs to instance A and the second set 
	of 4 to instance.

	When using hardware-based non-uniform memory access (NUMA) and the affinity 
	mask is set, every scheduler in a node binds to its own CPU. When the 
	affinity mask is not set, each scheduler is bound to the group of CPUs within 
	the NUMA node and a scheduler mapped to NUMA node N1 can schedule work on 
	any CPU in the node, but not on CPUs associated with another node.

	Any operation running on a single NUMA node can only use buffer pages from 
	that node. When an operation is run in parallel on CPUs from multiple nodes, 
	memory can be used from any node involved.

*/

USE AdventureWorks2017;
GO

-- Set PROCESS AFFINITY CPU = AUTO (8 cores)
ALTER SERVER CONFIGURATION SET PROCESS AFFINITY CPU = AUTO;
GO

-- Confirm that queries can use more than on core
-- maximum degree of parallelism (DOP) on server and database level
-- max degree of parallelism : 0
-- max degree of parallelism = 0 or max degree of parallelism > 0
SELECT
	'server' AS level, name, value_in_use
FROM
	sys.configurations
WHERE
	name = N'max degree of parallelism'
UNION ALL
SELECT
	'database' AS level, name, value
FROM
	sys.database_scoped_configurations
WHERE
	name = N'MAXDOP'
GO

-- Set cost threshold for parallelism to 50
EXEC sys.sp_configure 'cost threshold for parallelism', 50;
RECONFIGURE;
GO

-- cost threshold for parallelism : 50
SELECT
	name, value_in_use
FROM
	sys.configurations
WHERE
	name = N'cost threshold for parallelism';
GO

-- MAXDOP : 1
-- Degree of Parallelism : 1
SELECT
	ProductID, COUNT(*)
FROM
	Sales.SalesOrderDetailMedium
GROUP BY
	ProductID
OPTION (RECOMPILE, MAXDOP 1);
GO

-- Open Resource Monitor
-- All eight cores are busy
-- The scheduler moves between the cores although MaxDOP is set to 1

-- Run in another session
-- Only one thread and one scheduler is used because of the MAXDOP setting.
-- affinity : 255 = 1111 1111 (the scheduler can use all 8 cores)
DECLARE @session_id AS int;
-- Adjust the @session_id
SET @session_id = 78;
SELECT
	thr.affinity
  , se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.dop AS request_DOP
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , query_plan AS request_sql_query_plan
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.scheduler_id AS task_scheduler_id
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.thread_address AS worker_thread_address
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se
LEFT JOIN
	sys.dm_exec_requests AS re
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_os_tasks AS ta
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.sql_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1
	AND se.session_id = @session_id;
GO



-- Degree of Parallelism : 8
-- Branches : 2
-- Used Threads : 16
SELECT
	ProductID, COUNT(*)
FROM
	Sales.SalesOrderDetailMedium
GROUP BY
	ProductID
OPTION (RECOMPILE);
GO

-- Open Resource Monitor
-- All eight cores are busy, but the CPU consumption is much higher because 
-- sixteen threads are running in parallel.
-- The query uses seventeen threads on eight schedulers and the schedulers can move 
-- between the cores. 

-- Run in another session
-- All schedulers are busy
-- 17 threads on eight schedulers
-- affinity : 255 = 1111 1111 (the scheduler can use all 8 cores)
-- 16 + 1 threads
DECLARE @session_id AS int;
-- Adjust the @session_id
SET @session_id = 78;
SELECT
	thr.affinity
  , se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.dop AS request_DOP
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , query_plan AS request_sql_query_plan
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.scheduler_id AS task_scheduler_id
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.thread_address AS worker_thread_address
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se
LEFT JOIN
	sys.dm_exec_requests AS re
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_os_tasks AS ta
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.sql_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1
	AND se.session_id = @session_id;
GO



-- Set PROCESS AFFINITY CPU = 1 to 2 (CPU 1 + 2)
ALTER SERVER CONFIGURATION SET PROCESS AFFINITY CPU = 1 TO 2;
GO

-- Only scheduler 1 and 2 or online
SELECT *
FROM
	sys.dm_os_schedulers
WHERE
	status = N'VISIBLE ONLINE';
GO

-- MAXDOP : 1
-- Degree of Parallelism : 1
SELECT
	ProductID, COUNT(*)
FROM
	Sales.SalesOrderDetailMedium
GROUP BY
	ProductID
OPTION (RECOMPILE, MAXDOP 1);
GO

-- Open Resource Monitor
-- Only core 2 is busy
-- The query uses only one thread on one scheduler and the scheduler cannot 
-- move between the cores anymore due to the process affinity setting.

-- Run in another session
-- Only core 2 is busy 
-- The core is bound to scheduler 2
-- affinity : 2 = 0000 0010 (the scheduler can use core 2 only)
DECLARE @session_id AS int;
-- Adjust the @session_id
SET @session_id = 78;
SELECT
	thr.affinity
  , se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.dop AS request_DOP
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , query_plan AS request_sql_query_plan
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.scheduler_id AS task_scheduler_id
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.thread_address AS worker_thread_address
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se
LEFT JOIN
	sys.dm_exec_requests AS re
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_os_tasks AS ta
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.sql_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1
	AND se.session_id = @session_id;
GO



-- Degree of Parallelism : 2 due to processor affinitiy
SELECT
	ProductID, COUNT(*)
FROM
	Sales.SalesOrderDetailMedium
GROUP BY
	ProductID
OPTION (RECOMPILE);
GO

-- Open Resource Monitor
-- Only core 1 and 2 are busy
-- Core 2 is bound to scheduler 1
-- Core 3 is bound to scheduler 2
-- The query uses three threads on two scheduler and the schedulers cannot 
-- move between the cores anymore due to the process affinity setting.

-- Run in another session
-- 4 threads
-- Only core 1 and 2 are busy and only two schedulers are used
-- affinity : 2 = 0000 0010 (the scheduler can use core 2 only)
-- affinity : 4 = 0000 0100 (the scheduler can use core 3 only)
DECLARE @session_id AS int;
-- Adjust the @session_id
SET @session_id = 78;
SELECT
	thr.affinity
  , se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.dop AS request_DOP
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , query_plan AS request_sql_query_plan
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.scheduler_id AS task_scheduler_id
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.thread_address AS worker_thread_address
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se
LEFT JOIN
	sys.dm_exec_requests AS re
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_os_tasks AS ta
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.sql_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1
	AND se.session_id = @session_id;
GO


https://docs.microsoft.com/en-us/sysinternals/downloads/cpustres

-- C:\Program Files\CPU Stress
-- Produce a CPU workload of 100% on CPU1 (not CPU0)

-- Degree of Parallelism : 2
-- The query is almost blocked
SELECT
	ProductID, COUNT(*)
FROM
	Sales.SalesOrderDetailMedium
GROUP BY
	ProductID
OPTION (RECOMPILE);
GO

-- Run in another session
-- Only core 2 is used by the query. Core 1 is blocked. 
-- affinity : 2 = 0000 0010 (the scheduler can use core 2(1) only)
-- affinity : 4 = 0000 0100 (the scheduler can use core 3(2) only)
-- Core 1 : SUSPENDED | scheduler_runnable_tasks_count : 0
DECLARE @session_id AS int;
-- Adjust the @session_id
SET @session_id = 78;
SELECT
	thr.affinity
  , se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.dop AS request_DOP
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , query_plan AS request_sql_query_plan
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.scheduler_id AS task_scheduler_id
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.thread_address AS worker_thread_address
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se
LEFT JOIN
	sys.dm_exec_requests AS re
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_os_tasks AS ta
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.sql_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1
	AND se.session_id = @session_id;
GO

-- Housekeeping
ALTER SERVER CONFIGURATION SET PROCESS AFFINITY CPU = AUTO
GO

DBCC TRACEON(3604, -1);
DBCC TRACESTATUS;
GO


/*

	https://docs.microsoft.com/de-de/archive/blogs/psssql/sql-server-clarifying-the-numa-configuration-information

	Trace flag 8002 is used to treat the affinity mask as a group setting. 
	Usually the affinity mask sets the threads on the scheduler to only use one 
	CPU for the matching affinity bit. The trace flag tells SQL OS to treat the 
	mask as a group (process affinity like). It groups the bits for the same node 
	toghether and allow any scheduler ONLINE for that node to use any of the CPUs 
	that match the bits.

	Let us say you had the following affinity for NODE 0 on the system.

	0011 - Use CPU 1 and CPU 2

	Without the trace flag you would get a scheduler for CPU 1 and a scheduler 
	for CPU 2. The workers on scheduler 1 could only use CPU 1 and the workers 
	on scheduler 2 could only use CPU 2.

	With the trace flag you get the same scheduler layout but the thread on 
	scheduler 1 and scheduler 2 would set their affinity mask to 11 so they 
	could run on either CPU 1 or CPU 2. This allows you to configure an instance 
	of SQL to use a specific set of CPUs but not lock each scheduler into their 
	respective CPUs, allowing Windows to move the threads on a per CPU resource 
	use need.

*/



/*******************************************************************************

	parallelism - NUMA - latency

*******************************************************************************/

	https://docs.microsoft.com/en-us/sysinternals/downloads/coreinfo

	-- miscellaneous\numa.jpg

	-- C:\Program Files\Coreinfo\coreinfo.exe
	-- Coreinfo evaluates the approximate cross-NUMA Node access cost.
	-- Ensure that MAXDOP is set according to the NUMA architecture.

/*

	Logical Processor to NUMA Node Map:
	********--------  NUMA Node 0
	--------********  NUMA Node 1

	Approximate Cross-NUMA Node Access Cost (relative to fastest):
		 00  01
	00: 1.0 1.3
	01: 1.2 1.0

*/



/*******************************************************************************

	parallelism - NUMA - soft Numa

*******************************************************************************/

/*

	miscellaneous \ Parallelism MAXDOP.xlsx

	Starting with SQL Server 2016 (13.x), during service startup if the 
	Database Engine detects more than eight physical cores per NUMA node or 
	socket at startup, soft-NUMA nodes are created automatically by default. 
	The Database Engine places logical processors from the same physical core 
	into different soft-NUMA nodes. The recommendations in the table below are 
	aimed at keeping all the worker threads of a parallel query within the same 
	soft-NUMA node. This will improve the performance of the queries and 
	distribution of worker threads across the NUMA nodes for the workload.

*/

-- Get the soft numa configuration for machines with more than eight physical 
-- cores per NUMA node.
SELECT
	softnuma_configuration, softnuma_configuration_desc
FROM
	sys.dm_os_sys_info;
GO



/*******************************************************************************

	parallelism - query execution time - oltp

*******************************************************************************/

USE AdventureWorks2017
GO

SET STATISTICS TIME ON;
GO

-- Set cost threshold for parallelism to 5 (default)
EXEC sys.sp_configure N'cost threshold for parallelism', N'5';
RECONFIGURE;
GO

CHECKPOINT;
DBCC DROPCLEANBUFFERS;
GO

-- Execute in another session without discarding the results
-- Parallel execution with 8 cores
-- CXPACKET and CXCONSUMER waits
SELECT *
FROM
	dbo.big_table1 AS t1
INNER JOIN
	dbo.big_table1 AS t2
ON
	t1.col1 = t2.col1
	AND t1.col2 = t2.col2
OPTION (RECOMPILE);
--OPTION (RECOMPILE, MAXDOP 1);
--OPTION (RECOMPILE, MAXDOP 2);
--OPTION (RECOMPILE, MAXDOP 3);
--OPTION (RECOMPILE, MAXDOP 4);
--OPTION (RECOMPILE, MAXDOP 5);
--OPTION (RECOMPILE, MAXDOP 6);
--OPTION (RECOMPILE, MAXDOP 7);
GO

-- Set SPID accordingly
-- CXPACKET : 4103
-- CXCONSUMER : 0
DECLARE @session_id int = 77;
SELECT *
FROM
	sys.dm_exec_session_wait_stats
WHERE
	session_id = @session_id
	AND wait_type IN (
						 'CXPACKET', 'CXCONSUMER', 'CXSYNC_PORT'
					 );
GO

CHECKPOINT;
DBCC DROPCLEANBUFFERS;
GO

-- Execute in another session
-- Serial execution 
SELECT *
FROM
	dbo.big_table1 AS t1
INNER JOIN
	dbo.big_table1 AS t2
ON
	t1.col1 = t2.col1
	AND t1.col2 = t2.col2
OPTION (RECOMPILE, MAXDOP 1);
GO

-- Set SPID accordingly
-- CXPACKET : 0
-- CXCONSUMER : 0
DECLARE @session_id int = 62;
SELECT *
FROM
	sys.dm_exec_session_wait_stats
WHERE
	session_id = @session_id
	AND wait_type IN (
						 'CXPACKET', 'CXCONSUMER', 'CXSYNC_PORT'
					 );
GO

-- Housekeeping
EXEC sys.sp_configure N'cost threshold for parallelism', N'50';
RECONFIGURE;
GO

/*

	miscellaneous \ parallel query time and waits.pbix

	The parallel execution of the query causes an overhead resulting in longer 
	execution time, CXPACKET and CXCONSUMER waits. The more cores working for 
	the query, the longer the query waits for CXPACKET and CXCONSUMER and the 
	longer the total execution time but the CPU time in ms per core is almost 
	the same for all different parallelization degrees.

*/



/*******************************************************************************

	parallelism - query execution time - olap

*******************************************************************************/

USE AdventureWorks2017;
GO

SET STATISTICS IO, TIME ON;
GO

-- Rember this is a SQL Server which has 1 CPU with 8 cores and 6 GB memory 
-- only!

-- Sales.SalesOrderDetailBig has 500,000,000 records
SELECT SUM (rows) AS number_of_rows
FROM
	sys.partitions
WHERE
	object_id = OBJECT_ID ('Sales.SalesOrderDetailBigCSI', 'U')
	AND index_id = 0;
GO

-- Flush the buffer cache
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
GO

-- Columnstore index
-- Batch mode
-- Serial plan : OPTION(MAXDOP 1)
-- CPU time = 2062 ms,  elapsed time = 2122 ms.
SELECT
	YEAR (soh.OrderDate) AS OrderYear
  , pro.Name AS ProductName
  , SUM (sodb.OrderQty) AS TotalOrderQty
  , SUM (sodb.UnitPrice) AS TotalAmount
FROM
	Sales.SalesOrderDetailBigCSI AS sodb
INNER JOIN
	Sales.SalesOrderHeader AS soh
ON
	soh.SalesOrderID = sodb.SalesOrderID
INNER JOIN
	Production.Product AS pro
ON
	pro.ProductID = sodb.ProductID
WHERE
	soh.OrderDate BETWEEN CONVERT (datetime, '20110101') AND CONVERT (
																		 datetime
																	   , '20111231'
																	 )
GROUP BY
	YEAR (soh.OrderDate), pro.Name
OPTION (MAXDOP 1);
GO

-- Flush the buffer cache
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
GO

-- Columnstore index
-- Batch mode
-- Parallel plan
-- CPU time = 2437 ms,  elapsed time = 411 ms.
SELECT
	YEAR (soh.OrderDate) AS OrderYear
  , pro.Name AS ProductName
  , SUM (sodb.OrderQty) AS TotalOrderQty
  , SUM (sodb.UnitPrice) AS TotalAmount
FROM
	Sales.SalesOrderDetailBigCSI AS sodb
INNER JOIN
	Sales.SalesOrderHeader AS soh
ON
	soh.SalesOrderID = sodb.SalesOrderID
INNER JOIN
	Production.Product AS pro
ON
	pro.ProductID = sodb.ProductID
WHERE
	soh.OrderDate BETWEEN CONVERT (datetime, '20110101') AND CONVERT (
																		 datetime
																	   , '20111231'
																	 )
GROUP BY
	YEAR (soh.OrderDate), pro.Name;
GO



/*******************************************************************************

	parallelism  - CXPACKET (Class Exchange Packet)

*******************************************************************************/

/*

	The CXPACKET wait type occurs whenever a query is being executed in
	parallel.

	Parallel queries will use multiple worker threads to execute a request. 
	Along with the worker threads that are created to perform the work 
	requested, a parallel query will also use a 0 thread. 
	This 0 thread (control thread) is to coordinate the work of the other 
	worker threads.

	While the 0 thread is waiting for the other worker threads to finish the 
	work they were assigned to perform, it will record wait times of the 
	CXPACKET Wait Type.
	The SQL Server CXPACKET wait type is always present in parallel execution 
	even under an ideal scenario.
	
	A query will be as fast as the slowest thread.

	An exchange operator which executes in parallel has n producer threads 
	(MAXDOP) and n consumer threads (MAXDOP). 
	
	The maximum number of threads a repartiton streams operator can use is 
	2 * MAXDOP + 1, for example 2 * 8 + 1 = 17 threads.
	The maximum number of threads a distribute streams operator can use is 
	1 * MAXDOP + 1 + 1, for example 1 * 8 + 1 + 1 = 10 threads.
	The maximum number of threads a gather streams operator can use is 
	1 * MAXDOP + 1 + 1, for example 1 * 8 + 1 + 1 = 10 threads.

	The producers push data to consumers. Therefore the consumers may have to 
	wait for the data the producers pushes. 
	Consequently, the producer waits are the ones that may require attention, 
	while consumer waits are a passive consequence of longer running producers.
	
	To avoid CXPACKET

	*	Reduce query complexitiy and implement supportive indexes.
		
	*	Change the Cost Threshold for Parallelism so that the threshold is high 
		enough that your large queries can benefit from using parallelism but 
		your small queries do not experience a negative impact.

	*	Lowering the Max Degree of Parallelism
		
	*	Improving cardinality estimations if actual rows are very different 
		from estimations. Improving estimations can include actions such as 
		updating or adding statistics, revising the underlying index design.

	CXCONSUMER 
	Occurs when a consumer thread waits for a producer thread to send rows.
	This is a wait type that is a normal part of parallel query execution, and 
	cannot be directly influenced by changing the above mentioned 
	configurations.

	If CXPACKET is accompanied by a PAGEIOLATCH_XX, it is a sign that the speed 
	of the disk is too slow to satisfy the number of parallel read and write 
	requests. In this case it is better to reduce MAXDOP.

	If CXPACKET is accompanied by an LCK_M_XX, this is an indication that 
	parallelism is not the cause of the wait. The reason for high CXPACKET is a 
	lock on whose release a thread must wait.
	
*/



/*******************************************************************************

	parallelism - CXPACKET - coordinator thread

*******************************************************************************/

/*

	When executing parallel requests in row mode, the SQL Server Database 
	Engine assigns a worker to coordinate the child workers responsible for 
	completing tasks assigned to them (also 1:1), called the parent thread 
	(or coordinating thread). 
	The parent thread has a parent task associated with it. The parent thread 
	is the point of entry of the request and exists even before engine parses 
	a query. The main responsibilities of the parent thread are:

	*	coordinate a parallel scan.
	*	start child parallel workers.
	*	collect rows from parallel threads and send to the client.
	*	Perform local and global aggregations.

	If a query plan has serial and parallel branches, one of the parallel tasks 
	will be responsible for executing the serial branch.

	The SQL Server Database Engine will always try to assign schedulers from 
	the same NUMA node for task execution, and assign them sequentially 
	(in round-robin fashion) if schedulers are available. However, the worker 
	thread assigned to the parent task (coordinator thread) may be placed in a 
	different NUMA node from other tasks.
	The coordinating thread does not contribute to the MaxDOP limit.

	If CXPACKET accompanied with a LATCH_XX, PAGEIOLATCH_XX or SOS_SCHEDULER_YIELD 
	lower the MAXDOP value.
	
*/



/*******************************************************************************

	parallelism - actionable CXPACKET

*******************************************************************************/

USE AdventureWorks2017;
GO

-- Set cost threshold for parallelism to 5
EXEC sys.sp_configure N'cost threshold for parallelism', N'5';
RECONFIGURE;
GO

-- cost threshold for parallelism : 5
-- max degree of parallelism : 0 | 8
SELECT
	name, value_in_use
FROM
	sys.configurations
WHERE
	name = N'cost threshold for parallelism'
	OR name LIKE 'max degree of parallelism';
GO

-- Create a heap
DROP TABLE IF EXISTS dbo.SalesOrderDetail;
GO

SELECT *
INTO SalesOrderDetail
FROM
	Sales.SalesOrderDetail;
GO

-- Reset the wait stats
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
GO

SET STATISTICS IO, TIME ON;
GO

-- Update one record but leave the transaction open
BEGIN TRAN;
UPDATE SalesOrderDetail
SET OrderQty = 2
WHERE
	SalesOrderID = 45165;
GO

-- Execute in another session
-- The query is blocked
SELECT
	SalesOrderID
  , SalesOrderDetailID
  , CarrierTrackingNumber
  , OrderQty
  , ProductID
  , ModifiedDate
FROM
	dbo.SalesOrderDetail
ORDER BY
	OrderQty DESC
OPTION (RECOMPILE);
GO

-- Get details per operator per thread
-- The Table Scan and Sort operator threads are waiting for a LCK_M_S
-- All others report CXPACKET
DECLARE @session_id int = 57;
SELECT
	ot.session_id
  , eqp.node_id
  , ot.scheduler_id
  , eqp.physical_operator_name
  , last_wait_type
  , task_state
  , exec_context_id
  -- , worker_migration_count
  , sql_handle
  , plan_handle
  , row_count
  , estimate_row_count
FROM
	sys.dm_os_tasks AS ot
LEFT JOIN
	sys.dm_os_workers AS ow
ON
	ot.worker_address = ow.worker_address
LEFT JOIN
	sys.dm_exec_query_profiles AS eqp
ON
	ow.task_address = eqp.task_address
WHERE
	ot.session_id = @session_id
ORDER BY
	session_id, scheduler_id, node_id;
GO

-- The session reading SalesOrderDetail is blocked by the session updating the 
-- table at the same time
EXECUTE sp_who2;
GO

-- LCK_M_S and CXPACKET
-- The high CXPACKET is caused by LCK_M_S
DECLARE @session_id int = 53;
SELECT *
FROM
	sys.dm_os_waiting_tasks
WHERE
	session_id = @session_id
GO

-- Rollback the update statement
ROLLBACK
GO	

-- LCK_M_S and CXPACKET
SELECT *
FROM
	sys.dm_os_wait_stats
WHERE
	wait_type IN (
					 'LCK_M_S', 'CXPACKET', 'CXCONSUMER', 'CXSYNC_PORT'
				 )
ORDER BY
	wait_time_ms DESC;
GO

-- Housekeeping
DROP TABLE IF EXISTS dbo.SalesOrderDetail;
EXEC sys.sp_configure N'cost threshold for parallelism', N'5';
RECONFIGURE;
GO



/*******************************************************************************

	parallelism - threadpool starvation

*******************************************************************************/

/*

	Thread pool starvation occurs when there are no more free worker threads 
	available to process requests. 
	When this situation occurs, tasks that are currently waiting to be assigned
	to a worker thread will log the THREADPOOL Wait Type.
	
	The number of available worker threads are dependend on the number of CPUs
	and the OS architecture (32/64bit).

	Changing the setting "Maximum Worker Threads" to a higher value than the
	default can actually degrade the performance of your SQL Server because
	context-switching occurs far more often. 
	Another reason not to change the setting is that every worker thread 
	requires a bit of memory to operate; for 32-bit systems this is 512 KB per
	worker thread, and for 64-bit systems it is 2048 KB.

	On a very busy SQL Server Database Engine, it is possible to see a number 
	of active tasks that is over the limit set by reserved threads. These tasks 
	can belong to a branch that is not being used anymore and are in a 
	transient state, waiting for cleanup.

*/

-- Get the maximum number of worker threads
SELECT max_workers_count FROM sys.dm_os_sys_info;
GO

USE AdventureWorks2017;
GO

-- Set max worker threads to 128
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
EXEC sp_configure 'max worker threads', 128;
RECONFIGURE;
GO

-- Get the maximum number of worker threads
SELECT max_workers_count FROM sys.dm_os_sys_info;
GO

-- Set cost threshold for parallelism to 5 (default)
EXEC sys.sp_configure N'cost threshold for parallelism', N'5';
RECONFIGURE;
GO

-- cost threshold for parallelism : 5
-- max degree of parallelism : 0 | 8
SELECT
	name, value_in_use
FROM
	sys.configurations
WHERE
	name = N'cost threshold for parallelism'
	OR name LIKE 'max degree of parallelism';
GO

-- Force a serial plan!
-- Degree of Parallelism : 0
-- Costs : 47,0002
SELECT *
FROM
	Sales.SalesOrderDetailSmall
ORDER BY
	OrderQty DESC
OPTION (MAXDOP 1);
GO

-- Reset wait statistics
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
GO

-- execution time : 37 seconds
-- Run the SQL statement 2 times on 80 threads (configured : 128)
-- "ostress.exe" -S(local)\MYSQLSERVER2022A -dAdventureWorks2017 -Q"SELECT * FROM Sales.SalesOrderDetailSmall ORDER BY OrderQty DESC OPTION (MAXDOP 1);" -n80 -r2 -q

-- Get request details
SELECT
	se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.status AS request_status
  , re.dop AS request_dop
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.state AS worker_state
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se WITH (NOLOCK)
LEFT JOIN
	sys.dm_exec_requests AS re WITH (NOLOCK)
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_resource_governor_resource_pools AS po WITH (NOLOCK)
ON
	re.group_id = po.pool_id
LEFT JOIN
	sys.dm_os_tasks AS ta WITH (NOLOCK)
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch WITH (NOLOCK)
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo WITH (NOLOCK)
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr WITH (NOLOCK)
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.plan_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1;
GO

-- work_queue_count : 0
-- Number of schedulers for user requests (VISIBLE) is equal to the number of
-- logical CPUs
-- Current_tasks_count :
--	Number of current tasks that are associated with this scheduler. 
-- This count includes the following: 
--	Tasks that are waiting for a worker to execute them. 
--	Tasks that are currently waiting or running (in SUSPENDED or RUNNABLE state).
-- Runnable_tasks_count :
--	Number of workers, with tasks assigned to them, that are waiting to be
--	scheduled on the runnable queue
-- Current_workers_count :
--	Number of workers that are associated with this scheduler. 
--	This count includes workers that are not assigned any task
-- Active_workers_count :
--	Number of workers that are active. 
--	An active worker is never preemptive, must have an associated task, 
--	and is either running, runnable, or suspended
-- Work_queue_count :
--	Number of tasks in the pending queue. 
--	These tasks are waiting for a worker to pick them up
SELECT
	scheduler_id
,	current_tasks_count
,	runnable_tasks_count
,	current_workers_count
,	active_workers_count
,	work_queue_count
FROM sys.dm_os_schedulers WITH (NOLOCK)
WHERE status = 'VISIBLE ONLINE';
GO

-- No CXPACKET nor THREADPOOL
-- Wait_type : THREADPOOL
-- Wait_type : CXPACKET
SELECT *
FROM sys.dm_os_waiting_tasks WITH (NOLOCK)
WHERE
	wait_type IN ('THREADPOOL', 'CXPACKET', 'CXSYNC_PORT');
GO

-- Get the wait statistics
-- THREADPOOL : 0
-- CXPACKET : 0
SELECT *
FROM
	sys.dm_os_wait_stats
WHERE
	wait_type IN (
					 'THREADPOOL', 'CXPACKET', 'CXSYNC_PORT'
				 );
GO

-- Reset wait statistics
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
GO


-- Degree of Parallelism : 8
-- ThreadStat.Branches : 1
-- ThreadReservation.ReservedThreads : 8
SELECT *
FROM
	Sales.SalesOrderDetailSmall
ORDER BY
	OrderQty DESC;
GO 

-- Reset wait statistics
DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
GO

-- 80 concurrent threads x max 8 threads per query = max 640 threads
-- Run the SQL statement 2 times on 80 threads (configured : 128)
-- "ostress.exe" -S(local)\MYSQLSERVER2022A -dAdventureWorks2017 -Q"SELECT * FROM Sales.SalesOrderDetailSmall ORDER BY OrderQty DESC;" -n80 -r2 -q

/*

	The number of worker threads spawned for each task depends on the actual 
	available degree of parallelism (DOP) in the system based on current load. 
	This may differ from estimated DOP, which is based on the server 
	configuration for max degree of parallelism (MAXDOP). For example, the server
	configuration for MAXDOP may be 8 but the available DOP at runtime can be 
	only 2, which affects query performance.

	When a query or index operation starts executing on multiple worker threads 
	for parallel execution, the same number of worker threads is used until the 
	operation is completed. The SQL Server Database Engine re-examines the optimal 
	number of worker thread decisions every time an execution plan is retrieved 
	from the plan cache. For example, one execution of a query can result in the 
	use of a serial plan, a later execution of the same query can result in a 
	parallel plan using three worker threads, and a third execution can result in 
	a parallel plan using four worker threads.

*/

-- Get request details
-- request_dop : 1 to 8
-- The engine reduces the number of threads for a few queries (DOP)
SELECT
	se.session_id AS session_id
  , DB_NAME(re.database_id) AS request_database_name
  , re.status AS request_status
  , re.dop AS request_dop
  , re.parallel_worker_count AS request_parallel_worker_count
  , SUBSTRING(
				 t.text, (re.statement_start_offset / 2) + 1
			   , ((CASE re.statement_end_offset
					   WHEN -1
							THEN DATALENGTH(t.text)
					   ELSE re.statement_end_offset
				   END - re.statement_start_offset
				  ) / 2
				 ) + 1
			 ) AS request_statement_text
  , ta.task_address AS task_address
  , ta.task_state AS task_state
  , ta.context_switches_count AS task_context_switches_count
  , ta.exec_context_id AS task_exec_context_id
  , sch.scheduler_id AS scheduler_id
  , sch.cpu_id AS scheduler_cpu_id
  , sch.status AS scheduler_status
  , sch.is_idle AS scheduler_is_idle
  , sch.preemptive_switches_count AS scheduler_preemptive_switches_count
  , sch.context_switches_count AS scheduler_context_switches_count
  , sch.current_tasks_count AS scheduler_current_tasks_count
  , sch.runnable_tasks_count AS scheduler_runnable_tasks_count
  , sch.current_workers_count AS scheduler_current_workers_count
  , sch.active_workers_count AS scheduler_active_workers_count
  , sch.work_queue_count AS scheduler_work_queue_count
  , wo.worker_address AS worker_address
  , wo.is_preemptive AS worker_is_preemptive
  , wo.context_switch_count AS worker_context_switch_count
  , wo.state AS worker_state
  , wo.last_wait_type
  , thr.os_thread_id AS os_thread_id
FROM
	sys.dm_exec_sessions AS se WITH (NOLOCK)
LEFT JOIN
	sys.dm_exec_requests AS re WITH (NOLOCK)
ON
	re.session_id = se.session_id
LEFT JOIN
	sys.dm_resource_governor_resource_pools AS po WITH (NOLOCK)
ON
	re.group_id = po.pool_id
LEFT JOIN
	sys.dm_os_tasks AS ta WITH (NOLOCK)
ON
	ta.session_id = re.session_id
LEFT JOIN
	sys.dm_os_schedulers AS sch WITH (NOLOCK)
ON
	sch.scheduler_id = ta.scheduler_id
LEFT JOIN
	sys.dm_os_workers AS wo WITH (NOLOCK)
ON
	wo.worker_address = ta.worker_address
LEFT JOIN
	sys.dm_os_threads AS thr WITH (NOLOCK)
ON
	ta.worker_address = thr.worker_address
OUTER APPLY sys.dm_exec_sql_text(re.plan_handle) AS t
OUTER APPLY sys.dm_exec_query_plan(re.plan_handle) AS prd
WHERE
	is_user_process = 1;
GO

-- Threadpool starvation
-- work_queue_count > 0
-- Number of schedulers for user requests (VISIBLE) is equal to the number of
-- logical CPUs
-- Current_tasks_count :
--	Number of current tasks that are associated with this scheduler. 
-- This count includes the following: 
--	Tasks that are waiting for a worker to execute them. 
--	Tasks that are currently waiting or running (in SUSPENDED or RUNNABLE state).
-- Runnable_tasks_count :
--	Number of workers, with tasks assigned to them, that are waiting to be
--	scheduled on the runnable queue
-- Current_workers_count :
--	Number of workers that are associated with this scheduler. 
--	This count includes workers that are not assigned any task
-- Active_workers_count :
--	Number of workers that are active. 
--	An active worker is never preemptive, must have an associated task, 
--	and is either running, runnable, or suspended
-- Work_queue_count :
--	Number of tasks in the pending queue. 
--	These tasks are waiting for a worker to pick them up
SELECT
	scheduler_id
,	current_tasks_count
,	runnable_tasks_count
,	current_workers_count
,	active_workers_count
,	work_queue_count
FROM sys.dm_os_schedulers WITH (NOLOCK)
WHERE status = 'VISIBLE ONLINE';
GO

-- Wait_type : THREADPOOL
-- Wait_type : CXPACKET
-- Parallelism will cause CXPACKET and THREADPOOL starvation
SELECT *
FROM
	sys.dm_os_waiting_tasks WITH (NOLOCK)
WHERE
	wait_type IN (
					 'THREADPOOL', 'CXPACKET', 'CXSYNC_PORT'
				 )
ORDER BY
	wait_type DESC;
GO

-- Get the wait statistics
-- Threadpool starvation
-- THREADPOOL : 480145
-- CXPACKET : 1957040
SELECT *
FROM
	sys.dm_os_wait_stats
WHERE
	wait_type IN (
					 'THREADPOOL', 'CXPACKET', 'CXSYNC_PORT'
				 );
GO



-- The query uses more than one thread which will likely cause thread pool starvation
-- much faster.
-- Degree of Parallelism : 8
-- ThreadStat.Branches : 2
-- ThreadReservation.ReservedThreads : 16
SELECT *
FROM
	Sales.SalesOrderDetail AS sod
INNER JOIN
	Production.Product AS prd
ON
	sod.ProductID = prd.ProductID
WHERE
	SalesOrderDetailID > 10
ORDER BY
	Style;
GO

-- Reduce costs
CREATE NONCLUSTERED INDEX NCL_SalesOrderDetailSmall_OrderQty
ON Sales.SalesOrderDetailSmall (OrderQty)
INCLUDE (
			SalesOrderID
		  , SalesOrderDetailID
		  , CarrierTrackingNumber
		  , ProductID
		  , UnitPrice
		);
GO

-- Housekeeping
DROP INDEX IF EXISTS NCL_SalesOrderDetailSmall_OrderQty ON Sales.SalesOrderDetailSmall;
GO
EXEC sp_configure 'max worker threads', 0;
RECONFIGURE;
EXEC sys.sp_configure N'cost threshold for parallelism', N'50';
RECONFIGURE;
GO



/*******************************************************************************

	parallelism - threads, branches and execution context

*******************************************************************************/

/*

	Execution context
	
	When a cacheable batch is submitted to SQL Server for execution, it is 
	compiled and a query plan for it is put in the plan cache. There are at 
	most two instances of a query plan at any time in plan cache: one for all 
	of the serial executions and one for all of the parallel executions. 
	
	From a query plan, an execution context is derived. Execution contexts hold 
	the values needed for a specific execution of a query plan. Execution 
	contexts are also cached and reused by a serial plan only. Each user 
	concurrently executing a batch will have an execution context that holds 
	data (such as parameter values) specific to their execution. Although 
	execution contexts are reused, they are not reentrant (i.e., they are 
	single-threaded). That is, at any point of time, an execution context can 
	be executing only one batch submitted by a session, and while the execution 
	is happening, the context is not given to any other session or user.


	Branch
	
	If you think of an execution plan as a tree, a branch is an area of the plan that 
	groups one or more operators between Parallelism operators, also called Exchange 
	Iterators. 

	
	ThreadStat.Branches

	Number of branches that can run in parallel.
	A parallel hash join has three branches but	the hash join is divided into 
	a build phase and a probe phase. The Probe phase cannot begin execution 
	until the Build phase is complete. 
	Therefore, the number of concurrent branches is two and not three.


	ThreadReservation.ReservedThreads
	concurrent branches * runtime DOP

*/

USE AdventureWorks2017;
GO

EXEC sys.sp_configure N'cost threshold for parallelism', N'5';
RECONFIGURE;
GO

-- Discard results and include the actual execution plan
-- Branches : 1
-- Threads : 8
SELECT *
FROM
	dbo.big_table1 AS b1
INNER HASH JOIN
	dbo.big_table2 AS b2
ON
	b1.id = b2.id
OPTION (USE HINT ('ENABLE_PARALLEL_PLAN_PREFERENCE'));
GO

-- Merge Join is not blocking, therefore all branches can running in parallel
-- Degree of Parallelism : 8
-- ThreadStat.Branches : 3
-- ThreadReservation.ReservedThreads : 24
-- ThreadStat.UsedThreads : 24
SELECT *
FROM
	dbo.big_table1 AS b1
INNER MERGE JOIN
	dbo.big_table2 AS b2
ON
	b1.id = b2.id
OPTION (USE HINT ('ENABLE_PARALLEL_PLAN_PREFERENCE'));
GO
